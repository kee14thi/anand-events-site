# Anand Events Website

Official website for Anand Events – Turning Dreams Into Reality.
Built using React (Next.js style layout), elegant UI, and responsive design.
